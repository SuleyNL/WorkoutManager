package com.example.workoutmanager.models;

public class Exercise {

}
